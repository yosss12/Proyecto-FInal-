#include <ArduinoJson.h>

//  ASIGNACIÓN ELECTRÓNICA DE PINES - ARDUINO MEGA
const int pinFlujo1 = 2;          // Sensor de Flujo 1 -> Interrupción 0
const int pinFlujo2 = 3;          // Sensor de Flujo 2 -> Interrupción 1
const int pinValvula1 = 9;        // MOSFET Electroválvula 1
const int pinValvula2 = 10;       // MOSFET Electroválvula 2
const int pinInfraCarro1 = 4;     // Infrarrojo de corte 1 (Estación 1)
const int pinInfraCarro2 = 12;    // Infrarrojo de corte 2 (Estación 2)
const int pinGatillo1 = 5;        // Interruptor / Gatillo Bomba 1
const int pinGatillo2 = 11;       // Interruptor / Gatillo Bomba 2

//  PIN DE CONTROL PARA EL MOSFET DE LA BOMBA GENERAL
const int pinBombaAgua = 8;       // Gate del MOSFET del motor general

//  SENSOR ULTRASONICO (CISTERNA GENERAL)
const int pinTrig = 6;
const int pinEcho = 7;
const int distanciaVacio = 25;    
const int distanciaLleno = 4;     

// CONTADORES VOLÁTILES Y RELOJES DE FILTRADO (ANTI-RUIDO ELECTROMAGNÉTICO)
volatile unsigned long pulsosBomba1 = 0;
volatile unsigned long pulsosBomba2 = 0;
volatile unsigned long ultimoTiempoPulso1 = 0;
volatile unsigned long ultimoTiempoPulso2 = 0;

// 🔥 ESCALA CALIBRADA PARA LOS CAUDALÍMETROS Y LA PRESIÓN DEL MOTOR
const float factorEscala = 200.0;
//  Ignora los transitorios del encendido del motor
void contarPulsosBomba1() {
  if (micros() - ultimoTiempoPulso1 > 4000) { 
    pulsosBomba1++;
    ultimoTiempoPulso1 = micros();
  }
}

void contarPulsosBomba2() {
  if (micros() - ultimoTiempoPulso2 > 4000) {
    pulsosBomba2++;
    ultimoTiempoPulso2 = micros();
  }
}

float obtenerNivelCisterna() {
  digitalWrite(pinTrig, LOW); delayMicroseconds(2);
  digitalWrite(pinTrig, HIGH); delayMicroseconds(10);
  digitalWrite(pinTrig, LOW);
  long duracion = pulseIn(pinEcho, HIGH);
  int distancia = duracion * 0.034 / 2;
  if (distancia > distanciaVacio) distancia = distanciaVacio;
  if (distancia < distanciaLleno) distancia = distanciaLleno;
  return map(distancia, distanciaVacio, distanciaLleno, 0, 50); 
}

void setup() {
  Serial.begin(9600);
  
  // Inicialización de actuadores en estado lógico bajo (Apagados)
  pinMode(pinValvula1, OUTPUT); digitalWrite(pinValvula1, LOW); 
  pinMode(pinValvula2, OUTPUT); digitalWrite(pinValvula2, LOW); 
  pinMode(pinBombaAgua, OUTPUT); digitalWrite(pinBombaAgua, LOW); 

  // Configuración de sensores con resistencias Pull-Up activadas
  pinMode(pinInfraCarro1, INPUT_PULLUP); 
  pinMode(pinInfraCarro2, INPUT_PULLUP);
  pinMode(pinGatillo1, INPUT_PULLUP);
  pinMode(pinGatillo2, INPUT_PULLUP);

  pinMode(pinTrig, OUTPUT); 
  pinMode(pinEcho, INPUT);

  // Enlace de las interrupciones por hardware de los sensores de flujo
  pinMode(pinFlujo1, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(pinFlujo1), contarPulsosBomba1, RISING);
  
  pinMode(pinFlujo2, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(pinFlujo2), contarPulsosBomba2, RISING);
}

void loop() {
  // Cero impresiones de texto para resguardar el parser de C#
  
  if (Serial.available() > 0) {
    String jsonRecibido = Serial.readStringUntil('\n');
    StaticJsonDocument<200> doc;
    DeserializationError error = deserializeJson(doc, jsonRecibido);

    if (!error) {
      int idBomba = doc["id"];
      String comando = doc["comando"];
      float cantidadObjetivo = doc["cantidad"]; 

      
      // BOMBA 1
      
      if (idBomba == 1 && (comando == "tanquelleno" || comando == "prepago")) {
        pulsosBomba1 = 0;
        float litrosDespachados1 = 0.0;
        unsigned long tiempoFiltroArranque1 = 0;
        bool enArranque1 = false;

        while (true) {
          bool gatilloPresionado = (digitalRead(pinGatillo1) == LOW); 
          bool tanqueLleno = (digitalRead(pinInfraCarro1) == LOW);     
          
          if (gatilloPresionado && !tanqueLleno) {
            // 🔥 SECUENCIAMIENTO: Primero energizamos la electroválvula 1
            digitalWrite(pinValvula1, HIGH);  
            
            if (!enArranque1) {
              delay(80); // ⏱️ Ventaja crítica de voltaje para que abra la válvula antes de que arranque el motor
              tiempoFiltroArranque1 = millis();
              enArranque1 = true;
            }
            
            // Ahora sí encendemos el motor general sin que compitan por el arranque
            digitalWrite(pinBombaAgua, HIGH); 
            
            // Limpieza estricta de pulsos parásitos generados por el transitorio del motor (450ms)
            if (enArranque1 && (millis() - tiempoFiltroArranque1 < 450)) {
              pulsosBomba1 = 0;
            }
          } else {
            // Interrupción inmediata si se suelta el gatillo mecánico
            digitalWrite(pinBombaAgua, LOW);  
            digitalWrite(pinValvula1, LOW);   
            enArranque1 = false; 
          }

          litrosDespachados1 = (float)pulsosBomba1 / factorEscala;

          // Criterios automáticos de finalización de despacho
          if (comando == "tanquelleno" && tanqueLleno) break; 
          if (comando == "prepago" && (litrosDespachados1 >= cantidadObjetivo || tanqueLleno)) break; 

          delay(10); 
        }
        
        // Bloqueo total de seguridad post-despacho
        digitalWrite(pinBombaAgua, LOW); 
        digitalWrite(pinValvula1, LOW); 
        
        delay(250); // Estabilización hidráulica previa al muestreo analógico
        float inventarioTanque = obtenerNivelCisterna();

        // Estructura JSON pura hacia el hilo de C#
        Serial.print("{\"id\":1,\"evento\":\"finalizado\",\"consumo\":");
        Serial.print(litrosDespachados1, 2);
        Serial.print(",\"tanque\":");
        Serial.print(inventarioTanque, 2);
        Serial.println("}");
      }
     //BOMBA2
      else if (idBomba == 2 && (comando == "tanquelleno" || comando == "prepago")) {
        pulsosBomba2 = 0;
        float litrosDespachados2 = 0.0;
        unsigned long tiempoFiltroArranque2 = 0;
        bool enArranque2 = false;

        while (true) {
          bool gatilloPresionado = (digitalRead(pinGatillo2) == LOW);
          bool tanqueLleno = (digitalRead(pinInfraCarro2) == LOW);
          
          if (gatilloPresionado && !tanqueLleno) {
            // 🔥 SECUENCIAMIENTO: Primero energizamos la electroválvula 2
            digitalWrite(pinValvula2, HIGH);  
            
            if (!enArranque2) {
              delay(80); // ⏱️ Ventaja de voltaje para la válvula 2
              tiempoFiltroArranque2 = millis();
              enArranque2 = true;
            }
            
            digitalWrite(pinBombaAgua, HIGH); 
            
            if (enArranque2 && (millis() - tiempoFiltroArranque2 < 450)) {
              pulsosBomba2 = 0;
            }
          } else {
            digitalWrite(pinBombaAgua, LOW);  
            digitalWrite(pinValvula2, LOW);   
            enArranque2 = false;
          }

          litrosDespachados2 = (float)pulsosBomba2 / factorEscala;

          if (comando == "tanquelleno" && tanqueLleno) break; 
          if (comando == "prepago" && (litrosDespachados2 >= cantidadObjetivo || tanqueLleno)) break; 

          delay(10);
        }
        
        digitalWrite(pinBombaAgua, LOW); 
        digitalWrite(pinValvula2, LOW); 
        
        delay(250);
        float inventarioTanque = obtenerNivelCisterna();

        Serial.print("{\"id\":2,\"evento\":\"finalizado\",\"consumo\":");
        Serial.print(litrosDespachados2, 2);
        Serial.print(",\"tanque\":");
        Serial.print(inventarioTanque, 2);
        Serial.println("}");
      }
    }
  }
}