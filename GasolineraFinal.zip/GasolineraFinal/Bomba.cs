﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasolineraFinal
{
    internal class Bomba
    {
        private int id;
        private bool estadoActiva;
        private int numeroUsos;
        private double litrosDespachadosSumados;
        private double litrosDisponibles;

        public int Id { get { return id; } set { id = value; } }
        public bool EstadoActiva { get { return estadoActiva; } set { estadoActiva = value; } }
        public int NumeroUsos { get { return numeroUsos; } set { numeroUsos = value; } }
        public double LitrosDespachadosSumados { get { return litrosDespachadosSumados; } set { litrosDespachadosSumados = value; } }
        public double LitrosDisponibles { get { return litrosDisponibles; } set { litrosDisponibles = value < 0 ? 0 : value; } }

        public Bomba(int id, double capacidadInicial)
        {
            this.id = id;
            this.estadoActiva = true;
            this.numeroUsos = 0;
            this.litrosDespachadosSumados = 0.0;
            this.litrosDisponibles = capacidadInicial;
        }

        public void RegistrarDespacho(double litrosSurtidos)
        {
            this.numeroUsos++;
            this.litrosDespachadosSumados += litrosSurtidos;
            this.litrosDisponibles -= litrosSurtidos;
        }
    }
}
