﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasolineraFinal
{
    internal class Abastecimiento
    {
        private DateTime fecha;
        private Cliente cliente;
        private int idBomba;
        private double litros;
        private double precioDelDia;
        private double costoTotal;

        public DateTime Fecha { get { return fecha; } set { fecha = value; } }
        public Cliente Cliente { get { return cliente; } set { cliente = value; } }
        public int IdBomba { get { return idBomba; } set { idBomba = value; } }
        public double Litros { get { return litros; } set { litros = value; } }
        public double PrecioDelDia { get { return precioDelDia; } set { precioDelDia = value; } }
        public double CostoTotal { get { return costoTotal; } set { costoTotal = value; } }

        public Abastecimiento(Cliente cliente, int idBomba, double litros, double precioDelDia)
        {
            this.fecha = DateTime.Now;
            this.cliente = cliente;
            this.idBomba = idBomba;
            this.litros = litros;
            this.precioDelDia = precioDelDia;
            this.costoTotal = litros * precioDelDia;
        }

        public string ObtenerLineaBitacora()
        {
            return $"{fecha:yyyy-MM-dd HH:mm:ss}|{cliente.Nit}|{cliente.Nombre}|{idBomba}|{litros:F2}|{precioDelDia:F2}|{costoTotal:F2}";
        }
    }
}
