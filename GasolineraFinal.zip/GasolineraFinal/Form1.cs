﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GasolineraFinal
{
    public partial class Form1 : Form
    {
        private List<Abastecimiento> listaGlobalVentas = new List<Abastecimiento>();
        private Dictionary<string, string> baseDatosClientes = new Dictionary<string, string>();
        private SerialPort puertoSerial;
        private Bomba bomba1 = new Bomba(1, 50.0);
        private Bomba bomba2 = new Bomba(2, 50.0);
        private Combustible configuracionCombustible = new Combustible(25);

        private Cliente clienteBomba1 = null;
        private Cliente clienteBomba2 = null;
        private string rutaArchivo = "bitacora_estructurada.txt";
        public Form1()
        {
            InitializeComponent();
            LlenarBaseDatosMinima();

            // CONFIGURACIÓN CON LA "S" MAYÚSCULA
            puertoSerial = new SerialPort();
            puertoSerial.PortName = "COM11";
            puertoSerial.BaudRate = 9600;

            //  ESCUCHA CONSTANTE
            puertoSerial.DataReceived += new SerialDataReceivedEventHandler(PuertoSerial_DataReceived);

            // APERTURA INICIAL DE SEGURIDAD
            try
            {
                if (!puertoSerial.IsOpen)
                {
                    puertoSerial.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Aviso de conexión de hardware: " + ex.Message, "Verificación de Puerto COM");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox4.Text = configuracionCombustible.PrecioLitro.ToString("F2");

            string rutaClientes = "clientes_sat.txt";

            // lo creamos completamente EN BLANCO
            if (!File.Exists(rutaClientes))
            {
                try
                {
                    using (StreamWriter sw = File.CreateText(rutaClientes))
                    {
                        // No escribimos nada para que inicie limpio
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al inicializar el archivo de clientes: {ex.Message}");
                }
            }

            // Cargamos lo que esté guardado en el archivo plano
            try
            {
                baseDatosClientes.Clear(); // Limpiamos la RAM al arrancar

                string[] lineas = File.ReadAllLines(rutaClientes);
                foreach (string linea in lineas)
                {
                    if (!string.IsNullOrWhiteSpace(linea))
                    {
                        var datos = linea.Split('|');
                        if (datos.Length == 2)
                        {
                            string nit = datos[0].Trim().ToUpper();
                            string nombre = datos[1].Trim();

                            // Lo pasamos al diccionario de la RAM solo si no está repetido
                            if (!baseDatosClientes.ContainsKey(nit))
                            {
                                baseDatosClientes.Add(nit, nombre);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los clientes desde el archivo: {ex.Message}");
            }

            // Actualizamos la tabla de la pantalla (empezará vacía la primera vez)
            ActualizarTablaClientes();

            // APERTURA AUTOMÁTICA DEL PUERTO SERIAL
            try
            {
                if (!puertoSerial.IsOpen)
                {
                    puertoSerial.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"No se pudo conectar con el Arduino Mega: {ex.Message}",
                                "Error de Conexión Física", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            string nitBuscado = textBox1.Text.Trim().ToUpper();

            if (baseDatosClientes.ContainsKey(nitBuscado))
            {
                string[] partes = baseDatosClientes[nitBuscado].Split(' ');
                textBox2.Text = partes[0];
                textBox3.Text = partes.Length > 1 ? partes[1] : "";
                MessageBox.Show("Cliente encontrado en el sistema.", "Base de Datos SAT", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string nit = textBox1.Text.Trim().ToUpper();
            string nombreCompleto = $"{textBox2.Text.Trim()} {textBox3.Text.Trim()}";

            if (string.IsNullOrEmpty(nit) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Por favor, ingrese al menos el NIT y el Nombre.", "Datos Incompletos");
                return;
            }

            if (!baseDatosClientes.ContainsKey(nit))
            {
                try
                {
                    // 1. Lo metemos al diccionario en memoria para usarlo ya mismo
                    baseDatosClientes.Add(nit, nombreCompleto);

                    // Se escribe directo en el bloc de notas
                    string rutaClientes = "clientes_sat.txt";
                    using (StreamWriter sw = new StreamWriter(rutaClientes, true))
                    {
                        sw.WriteLine($"{nit}|{nombreCompleto}");
                    }

                    MessageBox.Show($"Cliente {nombreCompleto} registrado de forma permanente.", "SAT Éxito");

                    // Actualizamos la tabla para que aparezca en la cuadrícula
                    ActualizarTablaClientes();

                    // Limpiamos los campos
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error físico al escribir el cliente en el disco: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Este número de NIT ya está registrado en el sistema.", "NIT Duplicado");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox4.Text, out double nuevoPrecio))
            {
                configuracionCombustible.PrecioLitro = nuevoPrecio;
                MessageBox.Show($"Precio de venta actualizado: Q{configuracionCombustible.PrecioLitro:F2} por Litro.", "Precio Configurado");
            }
        }

        private void ActualizarTablaClientes()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = baseDatosClientes.Select(x => new { NIT = x.Key, NombreCompleto = x.Value }).ToList();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una opción en el menú de la Bomba 1.", "Aviso");
                return;
            }

            string seleccion = comboBox1.SelectedItem.ToString().Trim();

            if (seleccion == "Tanque Lleno" || seleccion == "Tanque lleno")
            {
                textBox6.Text = "0";
                textBox6.Enabled = false; // Bloquea el cuadro de texto porque no se usa dinero límite
                MessageBox.Show("Bomba 1 configurada para: TANQUE LLENO.\nEl flujo se detendrá automáticamente con el sensor infrarrojo.", "Modo Listo");
            }
            else // Si selecciona "Prepago"
            {
                textBox6.Enabled = true;  // Habilita el cuadro para ingresar los Quetzales
                textBox6.Clear();
                textBox6.Focus(); // Pone el cursor directo para escribir
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string nit = textBox5.Text.Trim().ToUpper();
            if (baseDatosClientes.ContainsKey(nit))
            {
                clienteBomba1 = new Cliente(baseDatosClientes[nit], nit);
                MessageBox.Show($"Cliente Validado: {clienteBomba1.Nombre}", "Bomba 1");
            }
            else
            {
                clienteBomba1 = new Cliente("Consumidor Final", "CF");
                textBox5.Text = "CF";
                MessageBox.Show("Asignado como Consumidor Final (CF).", "Bomba 1");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (clienteBomba1 == null) { MessageBox.Show("Por favor, confirme primero el cliente.", "Bomba 1 Bloqueada"); return; }
            if (comboBox1.SelectedItem == null) { MessageBox.Show("Seleccione una función.", "Aviso"); return; }

            string seleccion = comboBox1.SelectedItem.ToString().Trim().ToLower();
            string modo = "tanquelleno";
            double litrosEnvio = 0.0;

            if (seleccion == "prepago")
            {
                modo = "prepago";
                if (double.TryParse(textBox6.Text, out double monto) && monto > 0)
                {
                    //Removido el (int) que truncaba los litros a cero
                    litrosEnvio = monto / configuracionCombustible.PrecioLitro;
                }
                else
                {
                    MessageBox.Show("Por favor, ingrese un monto de prepago válido.", "Error de Monto");
                    return;
                }
            }

            // Armamos la trama JSON perfecta para el Arduino
            var json = new { id = 1, comando = modo, cantidad = litrosEnvio };

            if (puertoSerial != null && puertoSerial.IsOpen)
            {
                // Fuerza el punto decimal ignorando la región del sistema operativo Windows
                string comandoTrama = JsonConvert.SerializeObject(json, new JsonSerializerSettings
                {
                    Culture = System.Globalization.CultureInfo.InvariantCulture
                });

                puertoSerial.WriteLine(comandoTrama);

                
                // Podés usar una etiqueta en tu interfaz o dejar que corra directo al gatillo físico.
                Console.WriteLine("Trama enviada con éxito a Bomba 1: " + comandoTrama);
            }
            else
            {
                MessageBox.Show("El puerto serial está cerrado.", "Error");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una opción en el menú de la Bomba 2.", "Aviso");
                return;
            }

            string seleccion = comboBox2.SelectedItem.ToString().Trim();

            if (seleccion == "Tanque Lleno" || seleccion == "Tanque lleno")
            {
                textBox8.Text = "0";
                textBox8.Enabled = false; // Bloquea el cuadro de dinero de la Bomba 2
                MessageBox.Show("Bomba 2 configurada para: TANQUE LLENO.\nEl flujo se detendrá automáticamente con el sensor infrarrojo.", "Modo Listo");
            }
            else // Si selecciona "Prepago"
            {
                textBox8.Enabled = true;  // Libera el cuadro para ingresar los Quetzales en la Bomba 2
                textBox8.Clear();
                textBox8.Focus();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string nit = textBox7.Text.Trim().ToUpper();
            if (baseDatosClientes.ContainsKey(nit))
            {
                clienteBomba2 = new Cliente(baseDatosClientes[nit], nit);
                MessageBox.Show($"Cliente Validado: {clienteBomba2.Nombre}", "Bomba 2");
            }
            else
            {
                clienteBomba2 = new Cliente("Consumidor Final", "CF");
                textBox7.Text = "CF";
                MessageBox.Show("Asignado como Consumidor Final (CF).", "Bomba 2");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (clienteBomba2 == null)
            {
                MessageBox.Show("Por favor, confirme primero el cliente por seguridad.", "Bomba 2 Bloqueada");
                return;
            }
            if (comboBox2.SelectedItem == null)
            {
                MessageBox.Show("Seleccione una función (Prepago o Tanque Lleno).", "Aviso");
                return;
            }

            string seleccion = comboBox2.SelectedItem.ToString().Trim().ToLower();
            string modo = "tanquelleno";
            double litrosEnvio = 0.0;

            if (seleccion == "prepago")
            {
                modo = "prepago";
                if (double.TryParse(textBox8.Text, out double monto) && monto > 0)
                {
                    // Limpio de truncados molestos para la Bomba 2
                    litrosEnvio = monto / configuracionCombustible.PrecioLitro;
                }
                else
                {
                    MessageBox.Show("Por favor, ingrese un monto de prepago válido para la Bomba 2.", "Error de Monto");
                    return;
                }
            }

            // Armamos la trama JSON simétrica para la estación de despacho número 2
            var json = new { id = 2, comando = modo, cantidad = litrosEnvio };

            if (puertoSerial != null && puertoSerial.IsOpen)
            {
                // para que la Bomba 2 use punto decimal de forma estricta
                string comandoTrama = JsonConvert.SerializeObject(json, new JsonSerializerSettings
                {
                    Culture = System.Globalization.CultureInfo.InvariantCulture
                });

                puertoSerial.WriteLine(comandoTrama);

                //   bloqueante de la estación 2
                Console.WriteLine("Trama enviada con éxito a Bomba 2: " + comandoTrama);
            }
            else
            {
                MessageBox.Show("El puerto serial con el Arduino está cerrado. Verifique el cable USB.", "Error de Comunicación");
            }
        }

        private void PuertoSerial_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            try
            {
                //RECEPCIÓN FÍSICA REAL DESDE EL HARDWARE
                string datosRecibidos = puertoSerial.ReadLine();

                // Si no es un JSON válido, salimos del método sin procesar
                if (string.IsNullOrWhiteSpace(datosRecibidos) || !datosRecibidos.Trim().StartsWith("{"))
                {
                    return; // Ignora los "--- MONITOREO EN VIVO ---" y no se cae el programa
                }

                this.Invoke(new MethodInvoker(delegate
                {
                    var respuesta = JsonConvert.DeserializeAnonymousType(datosRecibidos, new { id = 0, evento = "", consumo = 0.0, tanque = 0.0 });

                    if (respuesta != null && respuesta.evento == "finalizado")
                    {
                        Cliente clienteActivo = respuesta.id == 1 ? clienteBomba1 : clienteBomba2;
                        if (clienteActivo == null) clienteActivo = new Cliente("Consumidor Final", "CF");

                        Abastecimiento venta = new Abastecimiento(clienteActivo, respuesta.id, respuesta.consumo, configuracionCombustible.PrecioLitro);
                        listaGlobalVentas.Add(venta);
                        GuardarVentaEnArchivo(venta);

                        if (respuesta.id == 1)
                        {
                            bomba1.RegistrarDespacho(respuesta.consumo);
                            bomba1.LitrosDisponibles = respuesta.tanque;
                        }
                        else
                        {
                            bomba2.RegistrarDespacho(respuesta.consumo);
                            bomba2.LitrosDisponibles = respuesta.tanque;
                        }

                        // Convertimos la lectura del tanque (0 a 50) a entero
                        int porcentajeTanque = Convert.ToInt32(respuesta.tanque);
                        int porcentajeReal = porcentajeTanque * 2; // Escala 0-100%

                        if (porcentajeReal < 0) porcentajeReal = 0;
                        if (porcentajeReal > 100) porcentajeReal = 100;

                        try
                        {
                            label14.Text = "Nivel de Cisterna: " + porcentajeReal + "%";
                            progressBar3.Value = porcentajeReal;

                            label14.Refresh();
                            progressBar3.Refresh();
                        }
                        catch (Exception) { }

                        MessageBox.Show($"[VENTA TERMINADA - BOMBA {respuesta.id}]\nCliente: {clienteActivo.Nombre}\nTotal: Q{venta.CostoTotal:F2}\nEstado Cisterna: {porcentajeReal}%", "Factura Generada");
                    }
                }));
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error en la recepción de datos seriales: " + ex.Message);
            }
        }

        private void GuardarVentaEnArchivo(Abastecimiento venta)
        {
            string rutaArchivo = "bitacora_estructurada.txt";

            // Deducción matemática exacta: Si los litros son mayores o iguales a 45 litros (o el tope de tu maqueta)
            // se guarda como Tanque lleno, si no, se procesa como Prepago.
            string tipoDespachoReal = (venta.Litros >= 45.0) ? "Tanque lleno" : "Prepago";

            try
            {
                using (StreamWriter sw = new StreamWriter(rutaArchivo, true))
                {
                    // Guardamos tu línea normal y le concatenamos el tipo detectado al final
                    sw.WriteLine($"{venta.ObtenerLineaBitacora()}|{tipoDespachoReal}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al escribir en la bitácora: " + ex.Message);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (comboBox3.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione un tipo de informe.", "Aviso");
                return;
            }

            string opcion = comboBox3.SelectedItem.ToString().Trim();
            DateTime fechaFiltro = dateTimePicker1.Value.Date;
            string rutaArchivo = "bitacora_estructurada.txt";

            if (!File.Exists(rutaArchivo))
            {
                MessageBox.Show("Aún no se ha creado el archivo de bitácora.", "Aviso");
                return;
            }

            try
            {
                // LEER Y PROCESAR TU BITÁCORA REAL LÍNEA POR LÍNEA
                var todasLasVentas = File.ReadAllLines(rutaArchivo)
                    .Where(linea => !string.IsNullOrWhiteSpace(linea))
                    .Select(linea =>
                    {
                        var datos = linea.Split('|');
                        double litros = double.Parse(datos[4]);

                        // Si la línea ya trae el 7mo campo lo usa
                        // si es de tus registros viejos, deduce según los litros automáticamente.
                        string tipo = (datos.Length > 7) ? datos[7].Trim() : ((litros >= 45.0) ? "Tanque lleno" : "Prepago");

                        return new
                        {
                            Fecha = DateTime.Parse(datos[0]),
                            Nit = datos[1],
                            Cliente = datos[2],
                            IdBomba = int.Parse(datos[3]),
                            Litros = litros,
                            PrecioDelDia = double.Parse(datos[5]),
                            CostoTotal = double.Parse(datos[6]),
                            TipoDespacho = tipo
                        };
                    }).ToList();

                // Creamos la lista base para aplicar los filtros LINQ de tu ComboBox
                var resultadoQuery = todasLasVentas.AsEnumerable();

               
                switch (opcion)
                {
                    case "Abastecimiento por dia":
                        resultadoQuery = todasLasVentas.Where(v => v.Fecha.Date == fechaFiltro);
                        break;

                    case "Prepago":
                        resultadoQuery = todasLasVentas.Where(v => v.TipoDespacho.Equals("Prepago", StringComparison.OrdinalIgnoreCase));
                        break;

                    case "Tanque lleno":
                        resultadoQuery = todasLasVentas.Where(v => v.TipoDespacho.Equals("Tanque lleno", StringComparison.OrdinalIgnoreCase));
                        break;

                    case "Bomba mas usada":
                        // Contamos cuántas líneas tiene cada bomba y seleccionamos el ID con el número más alto
                        var idMasUsado = todasLasVentas.GroupBy(v => v.IdBomba)
                                                       .OrderByDescending(g => g.Count())
                                                       .Select(g => g.Key)
                                                       .FirstOrDefault();
                        if (idMasUsado != 0)
                            resultadoQuery = todasLasVentas.Where(v => v.IdBomba == idMasUsado);
                        break;

                    case "Bomba menos usada":
                        // Ordenamos de forma ascendente para encontrar la bomba que menos renglones tiene en el txt
                        var idMenosUsado = todasLasVentas.GroupBy(v => v.IdBomba)
                                                         .OrderBy(g => g.Count())
                                                         .Select(g => g.Key)
                                                         .FirstOrDefault();
                        if (idMenosUsado != 0)
                            resultadoQuery = todasLasVentas.Where(v => v.IdBomba == idMenosUsado);
                        break;
                }

                var listaFinal = resultadoQuery.ToList();

                
                dataGridView2.DataSource = null; // Reseteo físico

                // Formateamos las columnas para que la entrega se mire impecable
                dataGridView2.DataSource = listaFinal.Select(v => new {
                    Fecha = v.Fecha.ToString("dd/MM/yyyy HH:mm"),
                    Cliente = v.Cliente,
                    Bomba = "Bomba " + v.IdBomba,
                    Litros = v.Litros.ToString("F2") + " L",
                    Precio = "Q " + v.PrecioDelDia.ToString("F2"),
                    Total = "Q " + v.CostoTotal.ToString("F2"),
                    Tipo = v.TipoDespacho
                }).ToList();

                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                if (listaFinal.Count == 0)
                {
                    MessageBox.Show("No hay registros guardados que coincidan con este informe.", "Filtro Vacío", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error de formato al procesar LINQ: " + ex.Message, "Error");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            DateTime fechaFiltro = dateTimePicker1.Value.Date;
            double dinero = listaGlobalVentas.Where(v => v.Fecha.Date == fechaFiltro).Sum(v => v.CostoTotal);
            double litros = listaGlobalVentas.Where(v => v.Fecha.Date == fechaFiltro).Sum(v => v.Litros);
            int conteo = listaGlobalVentas.Count(v => v.Fecha.Date == fechaFiltro);

            MessageBox.Show($"--- CIERRE DE CAJA ---\nFecha: {fechaFiltro:dd/MM/yyyy}\nVentas: {conteo}\nRecaudado: Q {dinero:F2}\nCombustible: {litros:F2} L", "Cierre Exitoso");
        }

        private void LlenarBaseDatosMinima()
        {
            baseDatosClientes.Add("1234567-K", "Bernie Alejandro Morales");
            baseDatosClientes.Add("7654321-1", "Maycol Morales");
            baseDatosClientes.Add("9988776-2", "Cristian Daniels");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (puertoSerial.IsOpen)
            {
                puertoSerial.Close(); // 🚨 Esto evita que el puerto COM se quede "trabado" en Windows
            }
        }
    }
}
