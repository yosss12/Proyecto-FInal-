﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasolineraFinal
{
    internal class Cliente
    {
        private string nombre;
        private string nit;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = string.IsNullOrWhiteSpace(value) ? "Consumidor Final" : value.Trim(); }
        }

        public string Nit
        {
            get { return nit; }
            set { nit = string.IsNullOrWhiteSpace(value) ? "CF" : value.Trim().ToUpper(); }
        }

        public Cliente(string nombre, string nit)
        {
            this.Nombre = nombre;
            this.Nit = nit;
        }
    }
}
