﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GasolineraFinal
{
    internal class Combustible
    {
        private double precioLitro;

        public double PrecioLitro
        {
            get { return precioLitro; }
            set { precioLitro = value <= 0 ? 14.50 : value; }
        }

        public Combustible(double precioInicial)
        {
            this.PrecioLitro = precioInicial;
        }
    }
}
